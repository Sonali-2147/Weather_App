import chalk from "chalk";
import validator from "validator";
//console.log(chalk.green.underline.inverse("true!"));
const email=validator.isEmail("abc@abccom");
console.log(email ?chalk.green.inverse(email):chalk.red.inverse(email));